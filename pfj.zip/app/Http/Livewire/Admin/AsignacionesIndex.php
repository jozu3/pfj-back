<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class AsignacionesIndex extends Component
{
    public function render()
    {
        return view('livewire.admin.asignaciones-index');
    }
}

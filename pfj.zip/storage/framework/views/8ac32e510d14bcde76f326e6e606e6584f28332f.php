<a href="/">
   <img src="<?php echo e(config('app.url', 'http://localhost/pfj/public').'/img/logo_pfj2022.jpg'); ?>" style="
							   	width: 250px;
							    border-radius: 50%;
							   " 
		alt="">
</a>
<?php /**PATH C:\xampp\htdocs\pfj\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'PFJ'); ?>

<?php $__env->startSection('content_header'); ?>
	<a href="<?php echo e(route('admin.inscripciones.create', 'idcontacto='.$contacto->id)); ?>" class="btn btn-success btn-sm float-right">Inscribir</a>
    <h1>Contacto: <?php echo e($contacto->nombres.' '.$contacto->apellidos); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('info')): ?>
    <div class="alert alert-success">
        <?php echo e(session('info')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<div class="row">		
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<?php echo Form::model($contacto, ['route' => ['admin.contactos.update', $contacto], 'method' => 'put', 'files' => true]); ?>


				<?php echo $__env->make('admin.contactos.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<div class="row">
					
				<div class="col-md-12">
						<?php echo Form::label('estado', 'Estado'); ?>

						<?php echo Form::select('estado', [
								'1' => 'No contactado',
								'2' => 'Contactado',
								'3' => 'Probable',
								'4' => 'Confirmado',
								'5' => 'Inscrito',
							], null, ['class' => 'form-control', 'placeholder' => 'Escoge', 'disabled' => 'disabled', 'style' => 'appearance: none; ']);; ?>

				</div>
				</div>
				<br>
				<div class="form-group">
				<?php echo Form::submit('Actualizar datos', ['class' => 'btn btn-primary']); ?>

				</div>
				<?php echo Form::close(); ?>

				
			</div>
		</div>
		
	</div>
	<div class="col-md-12">
		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.contacto-seguimientos', ['contacto' => $contacto])->html();
} elseif ($_instance->childHasBeenRendered('rKDJ0AV')) {
    $componentId = $_instance->getRenderedChildComponentId('rKDJ0AV');
    $componentTag = $_instance->getRenderedChildComponentTagName('rKDJ0AV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rKDJ0AV');
} else {
    $response = \Livewire\Livewire::mount('admin.contacto-seguimientos', ['contacto' => $contacto]);
    $html = $response->html();
    $_instance->logRenderedChild('rKDJ0AV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style type="text/css">
        .card-body {
            overflow: auto;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> 
		document.getElementById('imgperfil').addEventListener('change', cambiarImagen);

		function cambiarImagen(event){
			var file = event.target.files[0];

			var reader = new FileReader();
			reader.onload = (event) => {
				document.getElementById("img-show").setAttribute('src', event.target.result);
			};

			reader.readAsDataURL(file);
		}
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfj\resources\views/admin/contactos/show.blade.php ENDPATH**/ ?>
<img src="<?php echo e(config('app.url', 'http://localhost/pfj/public').'/img/pfj-lima-norte.png'); ?>" style="
							   	width: 75px
							    " 
		alt=""><?php /**PATH C:\xampp\htdocs\pfj\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>
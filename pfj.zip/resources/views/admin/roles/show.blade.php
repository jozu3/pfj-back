@extends('adminlte::page')

@section('title', 'PFJ')

@section('content_header')
    <h1>PFJ</h1>
@stop

@section('content')
    <p>Welcome to this beautiful admin panel.</p>
@stop

@section('css')
    <link rel="stylesheet" href="">
@stop

@section('js')
    <script> console.log('Hi!'); </script>
@stop
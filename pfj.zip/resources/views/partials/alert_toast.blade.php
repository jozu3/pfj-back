<div class="alert alert-warning alert-dismissible fade show" role="alert" style="position: fixed;
    top: 15%;
    right: 5px;">
  <strong>Holy guacamole!</strong> You should check in on some of those fields below.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>